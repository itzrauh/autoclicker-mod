package xyz.itzrauh.autoclicker.extension;

import lombok.Getter;
import lombok.Setter;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.Config;
import me.shedaniel.autoconfig.annotation.ConfigEntry;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;

@Config(name = "autoclicker")
@Getter
@Setter
public class AutoclickerClothConfig implements ConfigData {

    @ConfigEntry.Gui.Tooltip
    private int delayMs = 50;

    @ConfigEntry.Gui.Tooltip
    private boolean doubleClick = false;

    @ConfigEntry.Gui.Tooltip
    private ClickButton clickButton = ClickButton.LEFT;

    public enum ClickButton {
        LEFT, RIGHT
    }

    public static AutoclickerClothConfig get() {
        return AutoConfig.getConfigHolder(AutoclickerClothConfig.class).getConfig();
    }

    public static void register() {
        AutoConfig.register(AutoclickerClothConfig.class, GsonConfigSerializer::new);
    }
}