package xyz.itzrauh.autoclicker.hud;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import net.minecraft.text.Text;
import xyz.itzrauh.autoclicker.AutoclickerMod;
import xyz.itzrauh.autoclicker.engine.AutoclickerEngine;

public class AutoclickerHud {

    private static final int COLOR_GREEN = 0x55FF55;
    private static final String TEXT_ENABLED = "Autoclick: ACTIVADO";

    public static void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of(AutoclickerMod.MOD_ID, "status"),
                (graphics, tickCounter) -> {
                    if (!AutoclickerEngine.isEnabled()) return;

                    MinecraftClient client = MinecraftClient.getInstance();
                    if (client.player == null) return;

                    graphics.drawText(
                            client.textRenderer,
                            Text.literal(TEXT_ENABLED),
                            10,
                            10,
                            COLOR_GREEN,
                            true
                    );
                }
        );
    }
}

// Me estoy volviendo loco, este codigo es una aberracion he probado con HudRenderCallback y no PUTO FUNCIONA Y PORQUE ??? PUES NO TENGO NI IDEA SON LAS 04:45 DE LA MAÑANA Y NO PUEDO MAS
// TODAS MIS ESPERANZAS SON PARA IVO DIOS BENDIGA A IVO