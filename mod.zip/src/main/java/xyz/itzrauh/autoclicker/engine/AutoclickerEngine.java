package xyz.itzrauh.autoclicker.engine;

import lombok.Getter;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import xyz.itzrauh.autoclicker.AutoclickerMod;
import xyz.itzrauh.autoclicker.config.AutoclickerKeybind;
import xyz.itzrauh.autoclicker.extension.AutoclickerClothConfig;
import xyz.itzrauh.autoclicker.mixin.MinecraftClientInvoker;

@Slf4j
@UtilityClass
public class AutoclickerEngine {

    @Getter
    private static boolean enabled = false;

    private static long lastClickTime = 0;
    private static boolean wasKeyPressed = false;

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoclickerEngine::onTick);
    }

    private static void onTick(MinecraftClient client) {
        if (client.player == null) return;

        handleToggle(client);

        if (!enabled) return;
        if (client.currentScreen != null) return;

        handleClicking(client);
    }

    private static void handleToggle(MinecraftClient client) {
        boolean isPressed = AutoclickerKeybind.getToggleKey().isPressed();
        if (isPressed && !wasKeyPressed) {
            enabled = !enabled;
            AutoclickerMod.LOGGER.info("Autoclicker toggled: {}", enabled ? "ON" : "OFF");
            client.player.sendMessage(
                    Text.literal("AutoClicker: ")
                            .append(Text.literal(enabled ? "ACTIVADO" : "DESACTIVADO")
                                    .formatted(enabled ? Formatting.GREEN : Formatting.RED)),
                    true
            );
        }
        wasKeyPressed = isPressed;
    }

    private static void handleClicking(MinecraftClient client) {
        AutoclickerClothConfig config = AutoclickerClothConfig.get();
        long now = System.currentTimeMillis();

        if (now - lastClickTime >= config.getDelayMs()) {
            lastClickTime = now;
            click(client, config);
        }
    }

    private static void click(MinecraftClient client, AutoclickerClothConfig config) {
        sendClick(client, config.getClickButton());
        if (config.isDoubleClick()) {
            sendClick(client, config.getClickButton());
        }
    }

    private static void sendClick(MinecraftClient client, AutoclickerClothConfig.ClickButton button) {
        MinecraftClientInvoker invoker = (MinecraftClientInvoker) client;
        if (button == AutoclickerClothConfig.ClickButton.LEFT) {
            invoker.invokeDoAttack();
        } else {
            invoker.invokeDoItemUse();
        }
    }
}
