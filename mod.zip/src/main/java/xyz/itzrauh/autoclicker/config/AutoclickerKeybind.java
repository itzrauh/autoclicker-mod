package xyz.itzrauh.autoclicker.config;

import lombok.Getter;
import lombok.experimental.UtilityClass;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import xyz.itzrauh.autoclicker.AutoclickerMod;

@UtilityClass
public class AutoclickerKeybind {

    @Getter
    private static KeyBinding toggleKey;

    public static void register() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autoclicker.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                KeyBinding.Category.create(Identifier.of(AutoclickerMod.MOD_ID, "main"))
        ));
    }

}